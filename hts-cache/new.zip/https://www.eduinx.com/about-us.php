<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- 
    - primary meta tag
  -->
  <title>About EduInX | Leading the Way in Data Science Training</title>
  <meta name="title" content="About EduInX | Leading the Way in Data Science Training">
  <meta name="description" content="Discover EduInX, the experts in data science training. Learn about our mission to provide industry-leading education with 100% job-guaranteed programs.">
  <link rel="canonical" href="https://www.eduinx.com/about-us" />
  
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-62F9G5SR2M"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-62F9G5SR2M');
</script>
  

  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.png" type="image/svg+xml">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">
  <link rel="stylesheet" href="./assets/css/style1.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;500;600;700;800 family=Poppins:wght@400;500&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-bg.svg">
  <link rel="preload" as="image" href="./assets/images/hero-banner-1.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-banner-2.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-shape-1.svg">
  <link rel="preload" as="image" href="./assets/images/hero-shape-2.png">

  <style type="text/css">

  </style>
</head>

<body id="top">
  <!-- ============== HEADER ================ -->

  
  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="index" class="logo">
        <img src="./assets/images/logo/new_logo.png" width="162" height="auto" alt="eduinx logo">
      </a>

      <nav class="navbar" data-navbar>

        <div class="wrapper">
          <a href="index" class="logo">
            <img src="./assets/images/logo/new_logo.png" width="162" height="50" alt="eduinx logo">
          </a>

          <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
            <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
          </button>
        </div>

        <ul class="navbar-list">

          <li class="navbar-item">
            <a href="./index" class="navbar-link" data-nav-link>Home</a>
          </li>

          <li class="navbar-item">
            <a href="./about-us" class="navbar-link" data-nav-link>About</a>
          </li>

          <li class="navbar-item">
            <a href="./job-guaranteed-courses" class="navbar-link" data-nav-link>Courses</a>
          </li>

          <li class="navbar-item">
            <a href="./milestone-achievers" class="navbar-link" data-nav-link>Our Milestone</a>
          </li>

          <li class="navbar-item">
            <a href="https://eduinx.in/" class="navbar-link" data-nav-link>Blogs</a>
          </li> 

          <li>
            <a href="./webinar" class="navbar-link" data-nav-link>Webinar</a>
          </li>
          
         <li>
            <a href="../elevateX" class="navbar-link" data-nav-link>ElevateX</a>
          </li>


          <li class="navbar-item">
            <a href="./contact-us" class="navbar-link" data-nav-link>Contact</a>
          </li>

          

        </ul>

      </nav>

      <div class="header-actions">
         <!-- <a href="https://wa.me/917411464640" target="_blank" class="btn has-before" style="background-color:blue;">Free Counseling</a> -->

        <a href="contact-us" class="btn has-before">
          <span class="span">Apply Now</span>

          <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
        </a>

        <button class="header-action-btn" aria-label="open menu" data-nav-toggler>
          <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
        </button>

      </div>

      <div class="overlay" data-nav-toggler data-overlay></div>

    </div>
  </header>

<!-- -----------BODY START--------------- -->

<!-- =============- BANNER ============== -->

<section class="section hero has-bg-image" id="home" aria-label="home" style="background-image: url('./assets/images/hero-bg.svg'); height:200px;">
  <div class=" ">
    <h1 class="h1 section-title" style="margin-left: 50px; margin-right: 50px; text-align: center;"> WHO <span class="span" style="color: #b70b45;">WE</span> ARE? </h1> </div>
  </section>

  <section class="about" id="about" aria-label="about">
    <div class="container">

      <figure class="about-banner">
        <div class="img-holder" style="--width: 520; --height: 370;">
          <img src="./assets/images/about_us/banner1.jpeg" width="520" height="370" loading="lazy" alt="about banner" class="img-cover">
        </div>
        <img src="./assets/images/about-shape-3.png" width="722" height="528" loading="lazy" alt="" class="shape about-shape-3">
      </figure>

      <div class="about-content">
        <p class="section-subtitle">We at Eduinx</p>
        <h2 class="h2 section-title"> Lead with Skills<span class="span" style="color: #b70b45;"> Grow with</span> Mentorship </h2>
        <p class="section-text" style="font-family: var(--ff-league_spartan); color:var(--eerie-black-1); font-size: 18px;"> At Eduinx, we believe that knowledge is power and the key to success. That's why we are passionate about providing individuals with top-of-the-line conventional courses that will not only upskill them but also give them an edge in the ever-evolving corporate world.
        </p>
        <ul class="about-list" style="font-family: var(--ff-league_spartan); color:var(--eerie-black-1); font-size: 18px;">
          <li class="about-item">
            <ion-icon name="checkmark-done-outline" aria-hidden="true"></ion-icon>
            <span class="span">Trainers from top 1% industry leaders </span>
          </li>
          <li class="about-item">
            <ion-icon name="checkmark-done-outline" aria-hidden="true"></ion-icon>
            <span class="span">Industry oriented training program</span>
          </li>
          <li class="about-item">
            <ion-icon name="checkmark-done-outline" aria-hidden="true"></ion-icon>
            <span class="span">100% Interview Opportunity</span>
          </li>
        </ul>
      </div>

    </div>
    <div class="" style="margin-left: 50px; margin-right: 50px; font-family: var(--ff-league_spartan); color:var(--eerie-black-1); ">
      <p class="section-text" style="font-size:18px;">As an edu-leader in the market, we understand the demands of the job market and strive to bring our learners the most in-demand courses to help them achieve their career goals. Our team consists of industry experts who constantly update our course content to ensure that it aligns with current market trends.</p>
      <p class="section-text" style="font-size:18px;">We are dedicated to helping freshers and young professionals sustain a competitive edge through our expertly curated courses. We don't just teach, we empower our learners with real-world knowledge and skills so they can confidently climb the ladder of success in their chosen field. Join us and take your career to new heights!</p>
    </div>
  </section>

<!-- ============ OUR MISSION / VISION / CORE VALUES ================== -->

  <section style="background-color: lightgray;" class="guiding-principles-section">
    <div class="mvv-container" >
      <div class="mvv-block" >

        <div class="image">
          <img src="./assets/images/mission.jpg" alt="mission_image">
        </div>

        <div class="content" style="font-family: var(--ff-league_spartan); color: var(--eerie-black-1); font-size:20px;">
          <h5 style="font-size: 35px; color: #6dbe4f;">Our Mission</h5>
          <p style="font-size: 20px;">We at Eduinx offers an all-in-one platform for students, job seekers, and IT professionals to gain in-demand skills like CCNA, Linux, Full Stack development, Python programming, and data science through online courses. Take your tech career to the next level with Eduinx.</p>
        </div>

      </div>

      <div class="mvv-block">
        <div class="image">
          <img src="./assets/images/vision.jpg" alt="mission_image">
        </div>
        <div class="content" style="font-family: var(--ff-league_spartan); color: var(--eerie-black-1);">
          <h5 style="font-size: 35px; color: #6dbe4f;">Our Vision</h5>
          <p style="font-size: 20px;">At Eduinx, we aim to bridge the gap between theoretical knowledge and practical skills by providing top-notch online courses for CCNA+Linux, Full Stack Developer, Python Programming, and Data Science. Our industry expert instructors ensure that students, job seekers, and IT professionals alike are equipped with the technical education needed to succeed in their careers as we provide the tools and skills you need to succeed in the fast-paced world of technology.</p>
        </div>
      </div>

      <div class="mvv-block">
        <div class="image">
          <img src="./assets/images/values.jpeg" alt="mission_image">
        </div>
        <div class="content" style="font-family: var(--ff-league_spartan); color: var(--eerie-black-1); font-size: 20px;">
          <h5 style="font-size: 35px; color: #6dbe4f; ">Our Values</h5>
          <p style="font-size: 20px;">Our values are the foundation of everything we do and provide to our students;
            <ul style="font-family: var(--ff-league_spartan); color: var(--eerie-black-1); font-size: 18px;">
              <li>&nbsp; &#9679 Commitment to Excellence</li>
              <li>&nbsp; &#9679 Student-Centric Approach</li>
              <li>&nbsp; &#9679 Community Engagement</li>
              <li>&nbsp; &#9679 Innovation</li>
              <li>&nbsp; &#9679 Scalability</li>
            </ul>
          </p>
        </div>
      </div>
    </div>
  </section> 
<!-- =============TEAM ===================== -->

   <div class="heading">
       <h1 class="heading-title">Our Team</h1>
       <h3 class="heading-subtitle">Meet Our Team Members</h3>
     </div>
     
      <section class="team">
        <div class="card">
          
        <div class="circle">
          <div class="imgBox">
            <img src="./assets/images/team_members/avishek.png" alt="team1">
          </div>
        </div>

        <div class="content">
          <a href="https://www.linkedin.com/in/avishek-dash-53180596" target="_blank">
            <i class="fa fa-linkedin" aria-hidden="true"></i>
          </a>
          <h3>Avishek Dash</h3>

          <div class="textIcon">
            <h4>Co-founder - Training Ops & Placement</h4>
            <a href="team/avishek-das">
              <li class="fa fa-arrow-right" aria-hidden = "true"></li>
            </a>
          </div>
        </div>

      </div> 

      <!-- -------------------- -->
    <div class="card">
        <div class="circle">
          <div class="imgBox">
            <img src="./assets/images/team_members/swati_310.png" alt="swathi-shivanna">
          </div>
        </div>

        <div class="content">
          <a href="https://www.linkedin.com/in/swathi-shivanna-46937a3b" target="_blank">
            <i class="fa fa-linkedin" aria-hidden="true"></i>
          </a>
          <h3>Swathi Shivanna</h3>

          <div class="textIcon">
            <h4>Co-founder - Sales & Operation</h4>
            <a href="team/swathi-shivanna">
              <li class="fa fa-arrow-right" aria-hidden = "true"></li>
            </a>
          </div>
        </div>

      </div> 
<!-- -------------------------- -->
<div class="card">
        <div class="circle">
          <div class="imgBox">
            <img src="./assets/images/team_members/kavya.png" alt="kavya-srinivas">
          </div>
        </div>

        <div class="content">
          <a href="https://www.linkedin.com/in/kavya-srinivas-720349301" target="_blank">
            <i class="fa fa-linkedin" aria-hidden="true"></i>
          </a>
          <h3>Kavya Srinivasa</h3>

          <div class="textIcon">
            <h4>Head of Operations</h4>
            <a href="team/kavya-srinivas">
              <li class="fa fa-arrow-right" aria-hidden = "true"></li>
            </a>
          </div>
        </div>

      </div>

       <a href="our-team" class="btn has-before">
            <span class="span">View All Members</span>

            <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
          </a>
      </section>


<!-- -------BODY END -------------------------- -->

    <!-- 
    - #FOOTER
  -->

  <footer class="footer" style="background-image: url('./assets/images/footer-bg.png')">

    <div class="footer-top section">
      <div class="container grid-list">

        <div class="footer-brand">

          <a href="#" class="logo">
            <img src="./assets/images/logo/new_logo_white.png" width="162" height="50" alt="eduinx logo">
          </a>

          <p class="footer-brand-text">
            At Eduinx, we offer comprehensive online courses with expert instructors and cutting-edge curriculum, Eduinx is the perfect choice for those serious about success in the tech industry.
          </p>

         <!-- <div class="wrapper">
            <span class="span">Address:</span>

            <address class="address"> B-Block, BHIVE Workspace - No.112, AKR Tech Park, "A" and, 7th Mile Hosur Rd, Krishna Reddy Industrial Area, Bengaluru, Karnataka- s560068</address>
          </div> -->

          <div class="wrapper">
            <span class="span">Call:</span>

            <a href="tel:+917411464640" class="footer-link">+91 7411 464 640</a>
          </div>

          <div class="wrapper">
            <span class="span">Email:</span>

            <a href="mailto:support@eduinx.com" class="footer-link">support@eduinx.com</a>
          </div>

        </div>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Comapny</p>
          </li>

          <li>
            <a href="about-us" class="footer-link">About</a>
          </li>

          <li>
            <a href="job-guaranteed-courses" class="footer-link">Courses</a>
          </li>


          <li>
            <a href="policy/Privacy-Policy" class="footer-link">Privacy Policy</a>
          </li>

          <li>
            <a href="policy/terms-and-conditions" class="footer-link">Terms & Conditions</a>
          </li>

          <li>
            <a href="policy/refund-cancellation-policy" class="footer-link">Refund/Cancellation policy</a>
          </li>

          <!--<li>-->
          <!--  <a href="policy/cancellation-policy" class="footer-link">Cancellation Policy</a>-->
          <!--</li>-->

        </ul>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Links</p>
          </li>

          <li>
            <a href="contact-us" class="footer-link">Contact Us</a>
          </li>


          <li>
            <a href="instructors" class="footer-link">Instructor</a>
          </li> 

          <li>
            <a href="our-team" class="footer-link">Our Team</a>
          </li>

          <li>
            <a href="https://eduinx.in/" class="footer-link">Blogs</a>
          </li>

          <!--<li>-->
          <!--  <a href="news-updates" class="footer-link">News</a>-->
          <!--</li>-->
          
          <!--<li>
            <a href="current-openings" class="footer-link">Current Openings</a>
          </li> -->

          <li>
            <a href="faqs" class="footer-link">FAQs</a>
          </li>
          
          <li>
              <a
                href="https://www.google.com/search?sca_esv=0e58669465c64ea2&rlz=1C1CHBF_enIN1024IN1024&sxsrf=AE3TifPDQXz4KGp_OPnFaNKkzY5IjuTYkA:1750921551557&si=AMgyJEtREmoPL4P1I5IDCfuA8gybfVI2d5Uj7QMwYCZHKDZ-E1oJ7PBp83PEWzfEE9P0MDjL0cfOCHY1-lOgc1vdWqwnRkzMJyy_fGEJbvyYLZ_huGqqZ7dewNNaquMeY9EO6NJbz-X9&q=Eduinx+Pvt+Ltd+Reviews&sa=X&ved=2ahUKEwiQwfCIw46OAxUPzTgGHQGjKBYQ0bkNegQINBAE&cshid=1750921567441879&biw=1536&bih=695&dpr=1.25#lrd=0x890b8701b2132843:0x20a4928ed3930407,3,,,,"
                class="footer-link"
                >Review Us</a
              >
            </li>

        </ul>

        <div class="footer-list">

          <p class="footer-list-title">Contacts</p>

          <p class="footer-list-text">
            Enter your email address to register to our newsletter subscription
          </p>

          <form action="" class="newsletter-form">
            <input type="email" name="email_address" placeholder="Your email" required class="input-field">

            <button type="submit" class="btn has-before">
              <span class="span">Subscribe</span>

              <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
            </button>
          </form>

          <ul class="social-list">

            <li>
              <a href="https://www.facebook.com/profile.php?id=61554376480864&mibextid=nwBsNb" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.linkedin.com/company/eduinx-com/" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-linkedin"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.instagram.com/eduinx.s?igsh=aWFlYmExYTdxdDA5&utm_source=qr" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-instagram"></ion-icon>
              </a>
            </li>

            <!--<li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li> -->

            <li>
              <a href="https://www.youtube.com/@eduinx-LeadwithSkills" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-youtube"></ion-icon>
              </a>
            </li>

          </ul>

        </div>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          Copyright 2025 All Rights Reserved by <a href="https://www.eduinx.com/" class="copyright-link">eduinx</a>
        </p>

      </div>
    </div>

  </footer>

  <!-- 
    - #BACK TO TOP
  -->

  <a href="#top" class="back-top-btn" aria-label="back top top" data-back-top-btn>
    <ion-icon name="chevron-up" aria-hidden="true"></ion-icon>
  </a>





  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>