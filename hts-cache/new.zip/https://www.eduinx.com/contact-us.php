<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- 
    - primary meta tag
  -->
  <title>Contact EduInX | Get in Touch for Data Science Training</title>
  <meta name="title" content="Contact EduInX | Get in Touch for Data Science Training">
  <meta name="description" content="Have questions about our data science training? Contact EduInX today for expert guidance, 100% job-guaranteed programs, and personalized support.">

  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.png" type="image/svg+xml">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">
  <link rel="stylesheet" href="./assets/css/style1.css">
  <link rel="stylesheet" type="text/css" href="./assets/css/style2.css">

  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">


  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;500;600;700;800&family=Poppins:wght@400;500&display=swap"
    rel="stylesheet">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-bg.svg">
  <link rel="preload" as="image" href="./assets/images/hero-banner-1.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-banner-2.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-shape-1.svg">
  <link rel="preload" as="image" href="./assets/images/hero-shape-2.png">

</head>

<body id="top">

 <!-- ============== HEADER ================ -->

  
  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="index" class="logo">
        <img src="./assets/images/logo/new_logo.png" width="162" height="auto" alt="eduinx logo">
      </a>

      <nav class="navbar" data-navbar>

        <div class="wrapper">
          <a href="index" class="logo">
            <img src="./assets/images/logo/new_logo.png" width="162" height="50" alt="eduinx logo">
          </a>

          <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
            <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
          </button>
        </div>

        <ul class="navbar-list">

          <li class="navbar-item">
            <a href="./index" class="navbar-link" data-nav-link>Home</a>
          </li>

          <li class="navbar-item">
            <a href="./about-us" class="navbar-link" data-nav-link>About</a>
          </li>

          <li class="navbar-item">
            <a href="./job-guaranteed-courses" class="navbar-link" data-nav-link>Courses</a>
          </li>

          <li class="navbar-item">
            <a href="./milestone-achievers" class="navbar-link" data-nav-link>Our Milestone</a>
          </li>

          <li class="navbar-item">
            <a href="https://eduinx.in/" class="navbar-link" data-nav-link>Blogs</a>
          </li> 

          <li>
            <a href="./webinar" class="navbar-link" data-nav-link>Webinar</a>
          </li>
          
         <li>
            <a href="../elevateX" class="navbar-link" data-nav-link>ElevateX</a>
          </li>


          <li class="navbar-item">
            <a href="./contact-us" class="navbar-link" data-nav-link>Contact</a>
          </li>

          

        </ul>

      </nav>

      <div class="header-actions">
         <!-- <a href="https://wa.me/917411464640" target="_blank" class="btn has-before" style="background-color:blue;">Free Counseling</a> -->

        <a href="contact-us" class="btn has-before">
          <span class="span">Apply Now</span>

          <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
        </a>

        <button class="header-action-btn" aria-label="open menu" data-nav-toggler>
          <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
        </button>

      </div>

      <div class="overlay" data-nav-toggler data-overlay></div>

    </div>
  </header>

  <script
  src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous">     
  </script>
  </header>

  <main>
    <article>
  
 <body>
    <section class="contactus-cont">
        <div class="container cont">
            <span class="big-circle"></span>
            <img src="./assets/images/img/shape.png" class="square" alt="" />
            <div class="form">
                <div class="contact-info">
                    <h3 class="title">Let's get in touch</h3>
                    <p class="text">Reach out to us through any of the methods below, and we'll get back to you as soon as possible.</p>
                    <div class="info">
                        <div class="information">
                            <img src="./assets/images/img/location.png" class="icon" alt="" />
                            <p>B-Block, BHIVE Workspace - No.112, AKR Tech Park, "A" and, 7th Mile Hosur Rd, Krishna Reddy Industrial Area, Bengaluru, Karnataka 560068</p>
                        </div>
                        <div class="information">
                            <img src="./assets/images/img/email.png" class="icon" alt="" />
                            <p>support@eduinx.com</p>
                        </div>
                        <div class="information">
                            <img src="./assets/images/img/phone.png" class="icon" alt="" />
                            <p>+91 7411 464 640</p>
                        </div>
                    </div>
                    <div class="social-media">
                        <p>Connect with us :</p>
                        <div class="social-icons">
                            <a href="https://www.facebook.com/profile.php?id=61554376480864&mibextid=nwBsNb" target="_blank">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://www.instagram.com/eduinx.s?igsh=aWFlYmExYTdxdDA5&utm_source=qr" target="_blank">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="https://www.linkedin.com/company/eduinx-com/" target="_blank">
                                <i class="fab fa-linkedin-in"></i>
                            </a>

                            <a href="https://www.youtube.com/@EduInX-LeadwithSkills" target="_blank">
                                <i class="fab fa-youtube"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- ================ -->
                <div class="contact-form">
                    <span class="circle one"></span>
                    <span class="circle two"></span>
                    <form action="send_email.php" method="post" autocomplete="off">
                        <h3 class="title">Contact us</h3>
                        <div class="input-container">
                            <input type="text" name="name" class="input" required />
                            <label for="name">Full Name</label>
                            <span>Full Name</span>
                        </div>
                        <div class="input-container">
                            <input type="email" name="email" class="input" required />
                            <label for="email">Email</label>
                            <span>Email</span>
                        </div>
                        <div class="input-container">
                            <input type="hidden" name="country_code" value="+91">
                            <input type="tel" name="phone" class="input" pattern="[0-9]{10}" maxlength="10" required  >
                            <label for="phone">Phone</label>
                            <span>Phone</span>
                        </div>
                        <div class="input-container">
                            <input type="text" name="city" class="input" />
                            <label for="city">City</label>
                            <span>City</span>
                        </div>
                         <div class="input-container">
                        <input type="text" name="honeypot" id="honeypot" style="position: absolute; left: -9999px;">
                        </div>
                        

                        <div class="input-container textarea">
                            <textarea name="message" class="input"></textarea>
                            <label for="message">Message</label>
                            <span>Message</span>
                        </div>
                        
                          <input type="hidden" id="recaptchaResponse" name="recaptcha_response">
                          
                        <input type="submit" value="Send" class="btn-cont" />
                    </form>
                </div>
            </div>       
        </div>

    </section>
<!-- MAP -->
 
 <!-- ============== FOOTER ================ -->

    <!-- 
    - #FOOTER
  -->

  <footer class="footer" style="background-image: url('./assets/images/footer-bg.png')">

    <div class="footer-top section">
      <div class="container grid-list">

        <div class="footer-brand">

          <a href="#" class="logo">
            <img src="./assets/images/logo/new_logo_white.png" width="162" height="50" alt="eduinx logo">
          </a>

          <p class="footer-brand-text">
            At Eduinx, we offer comprehensive online courses with expert instructors and cutting-edge curriculum, Eduinx is the perfect choice for those serious about success in the tech industry.
          </p>

         <!-- <div class="wrapper">
            <span class="span">Address:</span>

            <address class="address"> B-Block, BHIVE Workspace - No.112, AKR Tech Park, "A" and, 7th Mile Hosur Rd, Krishna Reddy Industrial Area, Bengaluru, Karnataka- s560068</address>
          </div> -->

          <div class="wrapper">
            <span class="span">Call:</span>

            <a href="tel:+917411464640" class="footer-link">+91 7411 464 640</a>
          </div>

          <div class="wrapper">
            <span class="span">Email:</span>

            <a href="mailto:support@eduinx.com" class="footer-link">support@eduinx.com</a>
          </div>

        </div>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Comapny</p>
          </li>

          <li>
            <a href="about-us" class="footer-link">About</a>
          </li>

          <li>
            <a href="job-guaranteed-courses" class="footer-link">Courses</a>
          </li>


          <li>
            <a href="policy/Privacy-Policy" class="footer-link">Privacy Policy</a>
          </li>

          <li>
            <a href="policy/terms-and-conditions" class="footer-link">Terms & Conditions</a>
          </li>

          <li>
            <a href="policy/refund-cancellation-policy" class="footer-link">Refund/Cancellation policy</a>
          </li>

          <!--<li>-->
          <!--  <a href="policy/cancellation-policy" class="footer-link">Cancellation Policy</a>-->
          <!--</li>-->

        </ul>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Links</p>
          </li>

          <li>
            <a href="contact-us" class="footer-link">Contact Us</a>
          </li>


          <li>
            <a href="instructors" class="footer-link">Instructor</a>
          </li> 

          <li>
            <a href="our-team" class="footer-link">Our Team</a>
          </li>

          <li>
            <a href="https://eduinx.in/" class="footer-link">Blogs</a>
          </li>

          <!--<li>-->
          <!--  <a href="news-updates" class="footer-link">News</a>-->
          <!--</li>-->
          
          <!--<li>
            <a href="current-openings" class="footer-link">Current Openings</a>
          </li> -->

          <li>
            <a href="faqs" class="footer-link">FAQs</a>
          </li>
          
          <li>
              <a
                href="https://www.google.com/search?sca_esv=0e58669465c64ea2&rlz=1C1CHBF_enIN1024IN1024&sxsrf=AE3TifPDQXz4KGp_OPnFaNKkzY5IjuTYkA:1750921551557&si=AMgyJEtREmoPL4P1I5IDCfuA8gybfVI2d5Uj7QMwYCZHKDZ-E1oJ7PBp83PEWzfEE9P0MDjL0cfOCHY1-lOgc1vdWqwnRkzMJyy_fGEJbvyYLZ_huGqqZ7dewNNaquMeY9EO6NJbz-X9&q=Eduinx+Pvt+Ltd+Reviews&sa=X&ved=2ahUKEwiQwfCIw46OAxUPzTgGHQGjKBYQ0bkNegQINBAE&cshid=1750921567441879&biw=1536&bih=695&dpr=1.25#lrd=0x890b8701b2132843:0x20a4928ed3930407,3,,,,"
                class="footer-link"
                >Review Us</a
              >
            </li>

        </ul>

        <div class="footer-list">

          <p class="footer-list-title">Contacts</p>

          <p class="footer-list-text">
            Enter your email address to register to our newsletter subscription
          </p>

          <form action="" class="newsletter-form">
            <input type="email" name="email_address" placeholder="Your email" required class="input-field">

            <button type="submit" class="btn has-before">
              <span class="span">Subscribe</span>

              <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
            </button>
          </form>

          <ul class="social-list">

            <li>
              <a href="https://www.facebook.com/profile.php?id=61554376480864&mibextid=nwBsNb" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.linkedin.com/company/eduinx-com/" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-linkedin"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.instagram.com/eduinx.s?igsh=aWFlYmExYTdxdDA5&utm_source=qr" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-instagram"></ion-icon>
              </a>
            </li>

            <!--<li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li> -->

            <li>
              <a href="https://www.youtube.com/@eduinx-LeadwithSkills" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-youtube"></ion-icon>
              </a>
            </li>

          </ul>

        </div>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          Copyright 2025 All Rights Reserved by <a href="https://www.eduinx.com/" class="copyright-link">eduinx</a>
        </p>

      </div>
    </div>

  </footer>


  <!-- 
    - #BACK TO TOP
  -->

  <a href="#top" class="back-top-btn" aria-label="back top top" data-back-top-btn>
    <ion-icon name="chevron-up" aria-hidden="true"></ion-icon>
  </a>





  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>


    <script src="./assets/js/app.js"></script>
    
    
<!-- Load reCAPTCHA v3 Script -->
<script src="https://www.google.com/recaptcha/api.js?render=6LcctdkqAAAAALCvGrFwcr0an3-kiT--iD08bsVo"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const form = document.querySelector("form");

        form.addEventListener("submit", function (event) {
            event.preventDefault(); 
            
            grecaptcha.execute("6LcctdkqAAAAALCvGrFwcr0an3-kiT--iD08bsVo", { action: "submit" })
                .then(function (token) {
                    document.getElementById("recaptchaResponse").value = token;
                    form.submit(); 
                });
        });
    });
</script>


</body>
</html>
