<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- 
    - primary meta tag
  -->
  <title>ElevateX 2025 - Launch Your Career | EduInX</title>
  <meta name="title" content="ElevateX 2025 - Launch Your Career | EduInX">
  <meta name="description" content="Join ElevateX 2025, an exclusive placement initiative by EduInX designed to bridge the gap between talented students and industry-leading companies.">

  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.png" type="image/svg+xml">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">
  <link rel="stylesheet" href="./assets/css/style1.css">
  <link rel="stylesheet" href="./assets/css/elevateX.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;500;600;700;800&family=Poppins:wght@400;500&display=swap"
    rel="stylesheet">
  <link
    href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;800&display=swap"
    rel="stylesheet">

  <!-- 
    - FontAwesome for icons
  -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
  />

  

</head>

<body id="top">

  <!-- ============== HEADER ================ -->

  
  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="index" class="logo">
        <img src="./assets/images/logo/new_logo.png" width="162" height="auto" alt="eduinx logo">
      </a>

      <nav class="navbar" data-navbar>

        <div class="wrapper">
          <a href="index" class="logo">
            <img src="./assets/images/logo/new_logo.png" width="162" height="50" alt="eduinx logo">
          </a>

          <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
            <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
          </button>
        </div>

        <ul class="navbar-list">

          <li class="navbar-item">
            <a href="./index" class="navbar-link" data-nav-link>Home</a>
          </li>

          <li class="navbar-item">
            <a href="./about-us" class="navbar-link" data-nav-link>About</a>
          </li>

          <li class="navbar-item">
            <a href="./job-guaranteed-courses" class="navbar-link" data-nav-link>Courses</a>
          </li>

          <li class="navbar-item">
            <a href="./milestone-achievers" class="navbar-link" data-nav-link>Our Milestone</a>
          </li>

          <li class="navbar-item">
            <a href="https://eduinx.in/" class="navbar-link" data-nav-link>Blogs</a>
          </li> 

          <li>
            <a href="./webinar" class="navbar-link" data-nav-link>Webinar</a>
          </li>
          
         <li>
            <a href="../elevateX" class="navbar-link" data-nav-link>ElevateX</a>
          </li>


          <li class="navbar-item">
            <a href="./contact-us" class="navbar-link" data-nav-link>Contact</a>
          </li>

          

        </ul>

      </nav>

      <div class="header-actions">
         <!-- <a href="https://wa.me/917411464640" target="_blank" class="btn has-before" style="background-color:blue;">Free Counseling</a> -->

        <a href="contact-us" class="btn has-before">
          <span class="span">Apply Now</span>

          <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
        </a>

        <button class="header-action-btn" aria-label="open menu" data-nav-toggler>
          <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
        </button>

      </div>

      <div class="overlay" data-nav-toggler data-overlay></div>

    </div>
  </header>


<!-- BODY ----------------------- -->

  <div class="elevate-content">
    <!-- Hero Section -->
    <section id="hero" class="hero-section">
      <div class="hero-content">
        <span class="hero-subtitle">DATA SCIENCE PLACEMENT WEEK</span>
        <h1>Welcome to ElevateX – The Premier Data Science Placement Week!</h1>
        <p>
          A dynamic and exclusive Placement Week hosted by EduinX, designed to bridge the gap between top-tier Data Science talent and forward-thinking organizations. Connect with industry-ready candidates equipped with cutting-edge skills in Data Analysis, Machine Learning, and Statistical Modeling.
        </p>
        <div class="cta-buttons">
          <a href="https://forms.gle/HPHtrncNB3sWznEUA" class="btn primary"
            ><i class="fas fa-building"></i> Register Your Company</a
          >
        </div>
      </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about-section">
      <div class="container">
        <div class="section-header">
          <h2>🚀 What is ElevateX?</h2>
        </div>
        <p>
          ElevateX is a dynamic and exclusive Placement Week hosted by EduinX, designed to bridge the gap between top-tier Data Science talent and forward-thinking organizations. Over the course of one powerful week, recruiters get direct access to pre-screened, industry-ready candidates equipped with cutting-edge skills in Data Analysis, Machine Learning, Statistical Modeling, and Data Visualization.
        </p>

        <div class="stats-container">
          <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
            <h3>Data Scientists</h3>
            <p>Premium Talent Pool</p>
          </div>
          <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-robot"></i></div>
            <h3>ML Engineers</h3>
            <p>AI Specialists Ready</p>
          </div>
          <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-chart-bar"></i></div>
            <h3>Data Analysts</h3>
            <p>Industry Ready Experts</p>
          </div>
          <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
            <h3>Business Intelligence (BI) Analyst</h3>
            <p>High Demand Role</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Who Should Register -->
    <section id="participate" class="participate-section">
      <div class="container">
        <h2>Who Should Register?</h2>
        <div class="participate-cards">
          <div class="participate-card">
            <h3>🏢 Organizations & Companies</h3>
            <p>Organizations seeking top-tier data science talent for various roles:</p>
            <ul>
              <li>Data Scientists & Data Analysts</li>
              <li>ML Engineers & AI Specialists</li>
              <li>Business Intelligence Analysts</li>
              <li>Statistical Modelers</li>
            </ul>
          </div>
          <div class="participate-card">
            <h3>🚀 Business Types</h3>
            <p>All types of organizations looking to boost their data capabilities:</p>
            <ul>
              <li>Startups & Emerging Companies</li>
              <li>SMBs & Mid-sized Enterprises</li>
              <li>Large Corporations & MNCs</li>
              <li>Tech Companies & Data-driven Organizations</li>
            </ul>
          </div>
          <div class="participate-card">
            <h3>👥 Hiring Teams</h3>
            <p>Perfect for recruiting professionals who want streamlined hiring:</p>
            <ul>
              <li>Recruiters & Talent Acquisition Teams</li>
              <li>Hiring Managers & Team Leads</li>
              <li>HR Directors & People Ops</li>
              <li>Technical Leaders & CTOs</li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <!-- Why ElevateX -->
    <section id="why-join" class="why-join-section">
      <div class="container">
        <h2>🧠 Why ElevateX?</h2>
        <div class="benefits-container">
          <div class="benefit-card">
            <i class="fas fa-award"></i>
            <h3>Top-Quality Talent</h3>
            <p>Meet candidates who have been rigorously trained and vetted, ensuring they're job-ready</p>
          </div>
          <div class="benefit-card">
            <i class="fas fa-cogs"></i>
            <h3>Industry-Aligned Skills</h3>
            <p>Our candidates excel in real-world tools and technologies that drive today's data-driven enterprises</p>
          </div>
          <div class="benefit-card">
            <i class="fas fa-search"></i>
            <h3>Curated Matching</h3>
            <p>Save time with a curated selection of profiles that match your hiring needs</p>
          </div>
          <div class="benefit-card">
            <i class="fas fa-handshake"></i>
            <h3>Direct Engagement</h3>
            <p>Connect, interact, and hire without the typical recruitment overhead</p>
          </div>
          <!-- <div class="benefit-card">
            <i class="fas fa-dollar-sign"></i>
            <h3>Zero Cost Hiring</h3>
            <p>No hidden fees — companies can register and hire at no additional cost</p>
          </div> -->
        </div>
      </div>
    </section>

    <!-- Candidate Skillsets -->
    <section id="skillsets" class="participate-section">
      <div class="container">
        <h2>💡 Candidate Skillsets Include:</h2>
        <div class="participate-cards">
          <div class="participate-card">
            <h3>📊 Data Analysis</h3>
            <p>Extracting actionable insights from complex datasets using advanced analytical techniques and tools.</p>
          </div>
          <div class="participate-card">
            <h3>🤖 Machine Learning</h3>
            <p>Building predictive models and intelligent systems using cutting-edge ML algorithms and frameworks.</p>
          </div>
          <div class="participate-card">
            <h3>📈 Statistical Modeling</h3>
            <p>Applying advanced statistical methods for business problem-solving and data-driven decision making.</p>
          </div>
          <div class="participate-card">
            <h3>📉 Data Visualization</h3>
            <p>Crafting impactful visual stories with tools like Tableau, Power BI, and Python libraries.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Placement Week Details -->
    <section id="schedule" class="schedule-section">
      <div class="container">
        <h2>📅 Placement Week Details</h2>
        <div class="schedule-container">
          <div class="event-card">
            <div class="event-icon">
              <i class="fas fa-calendar-check"></i>
            </div>
            <div class="event-date">
              <i class="far fa-calendar-alt"></i> June 14-21
            </div>
            <h3 class="event-title">Placement Week Dates</h3>
            <p class="event-description">
              Complete placement activities over one powerful week with direct access to pre-screened candidates.
            </p>
          </div>

          <div class="event-card">
            <div class="event-icon">
              <i class="fas fa-laptop"></i>
            </div>
            <div class="event-date">
              <i class="fas fa-globe"></i> Virtual Mode
            </div>
            <h3 class="event-title">100% Virtual</h3>
            <p class="event-description">
              Connect and hire from anywhere. No geographical limitations - access talent from across India.
            </p>
          </div>

          <div class="event-card">
            <div class="event-icon">
              <i class="fas fa-dollar-sign"></i>
            </div>
            <div class="event-date">
              <i class="fas fa-gift"></i> Free Registration
            </div>
            <h3 class="event-title">Zero Cost Hiring</h3>
            <p class="event-description">
              No registration fees, no hidden costs. Companies can register and hire completely free of charge.
            </p>
          </div>

          <div class="event-card">
            <div class="event-icon">
              <i class="fas fa-clock"></i>
            </div>
            <div class="event-date">
              <i class="fas fa-hourglass-half"></i> Limited Slots
            </div>
            <h3 class="event-title">Early Access Priority</h3>
            <p class="event-description">
              Limited slots available! Register early to ensure your organization gets priority access to top talent.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- Companies -->
    <section id="companies" class="companies-section">
      <div class="container">
        <h2>Featured Companies</h2>
        <p class="section-subtitle">
          Join 50+ industry leaders at our exclusive event
        </p>
        <div class="company-logos">
          <div class="company-logo"><img src="assets/images/compainies/company/TATAPOWER.png" alt="Tata Power"><span>Tata Power</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/247-ai.png" alt="[24]7.ai"><span>[24]7.ai</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/Perfios.png" alt="Perfios"><span>Perfios</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/emplay.png" alt="Emplay"><span>Emplay</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/Tekion.png" alt="Tekion"><span>Tekion</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/beroe.png" alt="Beroe"><span>Beroe</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/thinq24.png" alt="Thinq 24 TM"><span>Thinq 24 TM</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/atkinsrealis.png" alt="AtkinsRealis"><span>AtkinsRealis</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/wipro.png" alt="Wipro"><span>Wipro</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/zeapl.png" alt="Zeapl.ai"><span>Zeapl.ai</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/enzen.png" alt="Enzen"><span>Enzen</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/connectrz.png" alt="Connectrz"><span>Connectrz</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/lumiq.png" alt="Lumiq"><span>Lumiq</span></div>
          <div class="company-logo"><img src="assets/images/compainies/company/pra.png" alt="PRA Building Future Together"><span>PRA Building Future Together</span></div>
        </div>
      </div>
    </section>

    <!-- Testimonials -->
    <!-- <section id="testimonials" class="testimonials-section">
      <div class="container">
        <h2>Success Stories</h2>
        <div class="testimonial-container">
          <div class="testimonial">
            <div class="testimonial-text">
              <p>
                "ElevateX completely changed my career trajectory. I got placed
                at my dream company!"
              </p>
            </div>
            <div class="testimonial-author">
              <h4>Priya Singh</h4>
              <p>Software Developer, Google</p>
            </div>
          </div>
          <div class="testimonial">
            <div class="testimonial-text">
              <p>
                "We found exceptional talent through ElevateX. The quality of
                candidates was outstanding."
              </p>
            </div>
            <div class="testimonial-author">
              <h4>Rahul Sharma</h4>
              <p>HR Manager, Infosys</p>
            </div>
          </div>
        </div>
      </div>
    </section> -->

    <!-- How it Works -->
    <section id="how-it-works" class="register-section">
      <div class="container">
        <h2>🌟 How it Works</h2>
        <div class="register-cards">
          <div class="register-card">
            <h3>1️⃣ Register Your Company</h3>
            <p>Sign up using the registration link below to get access to our exclusive talent pool.</p>
          </div>
          <div class="register-card">
            <h3>2️⃣ Access Candidate Pool</h3>
            <p>Get exclusive access to our curated selection of trained and vetted data science professionals.</p>
          </div>
          <div class="register-card">
            <h3>3️⃣ Interview & Hire</h3>
            <p>We facilitate introductions, you choose the best fits for your team through direct interviews.</p>
          </div>
          <div class="register-card">
            <h3>4️⃣ Onboard Quickly</h3>
            <p>Ensure your new hires start adding value from Day 1 with our job-ready candidates.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Registration -->
    <section id="register" class="register-section">
      <div class="container">
        <h2>📢 Register Your Company Now!</h2>
        <div class="register-cards">
          <div id="company-register" class="register-card">
            <h3>🏢 Company Registration</h3>
            <p>Limited Slots Available! Don't miss the chance to elevate your team with ElevateX.</p>
            <a href="https://forms.gle/HPHtrncNB3sWznEUA" class="btn primary">REGISTER HERE</a>
          </div>
        </div>
      </div>
    </section>

    <!-- FAQ -->
    <section id="faq" class="faq-section">
      <div class="container">
        <h2>Frequently Asked Questions</h2>
        <div class="faq-container">
          <div class="faq-item">
            <div class="faq-question">
              <h3>Is there a registration fee?</h3>
              <span class="faq-toggle">+</span>
            </div>
            <div class="faq-answer">
              <p>No, the registration is completely free for all students.</p>
            </div>
          </div>
          <div class="faq-item">
            <div class="faq-question">
              <h3>Is it online or offline?</h3>
              <span class="faq-toggle">+</span>
            </div>
            <div class="faq-answer">
              <p>
                ElevateX 2025 will be conducted in a hybrid mode with both
                online and offline components.
              </p>
            </div>
          </div>
          <div class="faq-item">
            <div class="faq-question">
              <h3>What documents are required?</h3>
              <span class="faq-toggle">+</span>
            </div>
            <div class="faq-answer">
              <p>
                Students should have their resume, ID proof, educational
                certificates, and portfolio (if applicable).
              </p>
            </div>
          </div>
          <div class="faq-item">
            <div class="faq-question">
              <h3>Will I get an offer letter on the spot?</h3>
              <span class="faq-toggle">+</span>
            </div>
            <div class="faq-answer">
              <p>
                As per company norms
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>


  </div>

 
 <!-- ============== FOOTER ================ -->

    <!-- 
    - #FOOTER
  -->

  <footer class="footer" style="background-image: url('./assets/images/footer-bg.png')">

    <div class="footer-top section">
      <div class="container grid-list">

        <div class="footer-brand">

          <a href="#" class="logo">
            <img src="./assets/images/logo/new_logo_white.png" width="162" height="50" alt="eduinx logo">
          </a>

          <p class="footer-brand-text">
            At Eduinx, we offer comprehensive online courses with expert instructors and cutting-edge curriculum, Eduinx is the perfect choice for those serious about success in the tech industry.
          </p>

         <!-- <div class="wrapper">
            <span class="span">Address:</span>

            <address class="address"> B-Block, BHIVE Workspace - No.112, AKR Tech Park, "A" and, 7th Mile Hosur Rd, Krishna Reddy Industrial Area, Bengaluru, Karnataka- s560068</address>
          </div> -->

          <div class="wrapper">
            <span class="span">Call:</span>

            <a href="tel:+917411464640" class="footer-link">+91 7411 464 640</a>
          </div>

          <div class="wrapper">
            <span class="span">Email:</span>

            <a href="mailto:support@eduinx.com" class="footer-link">support@eduinx.com</a>
          </div>

        </div>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Comapny</p>
          </li>

          <li>
            <a href="about-us" class="footer-link">About</a>
          </li>

          <li>
            <a href="job-guaranteed-courses" class="footer-link">Courses</a>
          </li>


          <li>
            <a href="policy/Privacy-Policy" class="footer-link">Privacy Policy</a>
          </li>

          <li>
            <a href="policy/terms-and-conditions" class="footer-link">Terms & Conditions</a>
          </li>

          <li>
            <a href="policy/refund-cancellation-policy" class="footer-link">Refund/Cancellation policy</a>
          </li>

          <!--<li>-->
          <!--  <a href="policy/cancellation-policy" class="footer-link">Cancellation Policy</a>-->
          <!--</li>-->

        </ul>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Links</p>
          </li>

          <li>
            <a href="contact-us" class="footer-link">Contact Us</a>
          </li>


          <li>
            <a href="instructors" class="footer-link">Instructor</a>
          </li> 

          <li>
            <a href="our-team" class="footer-link">Our Team</a>
          </li>

          <li>
            <a href="https://eduinx.in/" class="footer-link">Blogs</a>
          </li>

          <!--<li>-->
          <!--  <a href="news-updates" class="footer-link">News</a>-->
          <!--</li>-->
          
          <!--<li>
            <a href="current-openings" class="footer-link">Current Openings</a>
          </li> -->

          <li>
            <a href="faqs" class="footer-link">FAQs</a>
          </li>
          
          <li>
              <a
                href="https://www.google.com/search?sca_esv=0e58669465c64ea2&rlz=1C1CHBF_enIN1024IN1024&sxsrf=AE3TifPDQXz4KGp_OPnFaNKkzY5IjuTYkA:1750921551557&si=AMgyJEtREmoPL4P1I5IDCfuA8gybfVI2d5Uj7QMwYCZHKDZ-E1oJ7PBp83PEWzfEE9P0MDjL0cfOCHY1-lOgc1vdWqwnRkzMJyy_fGEJbvyYLZ_huGqqZ7dewNNaquMeY9EO6NJbz-X9&q=Eduinx+Pvt+Ltd+Reviews&sa=X&ved=2ahUKEwiQwfCIw46OAxUPzTgGHQGjKBYQ0bkNegQINBAE&cshid=1750921567441879&biw=1536&bih=695&dpr=1.25#lrd=0x890b8701b2132843:0x20a4928ed3930407,3,,,,"
                class="footer-link"
                >Review Us</a
              >
            </li>

        </ul>

        <div class="footer-list">

          <p class="footer-list-title">Contacts</p>

          <p class="footer-list-text">
            Enter your email address to register to our newsletter subscription
          </p>

          <form action="" class="newsletter-form">
            <input type="email" name="email_address" placeholder="Your email" required class="input-field">

            <button type="submit" class="btn has-before">
              <span class="span">Subscribe</span>

              <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
            </button>
          </form>

          <ul class="social-list">

            <li>
              <a href="https://www.facebook.com/profile.php?id=61554376480864&mibextid=nwBsNb" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.linkedin.com/company/eduinx-com/" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-linkedin"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.instagram.com/eduinx.s?igsh=aWFlYmExYTdxdDA5&utm_source=qr" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-instagram"></ion-icon>
              </a>
            </li>

            <!--<li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li> -->

            <li>
              <a href="https://www.youtube.com/@eduinx-LeadwithSkills" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-youtube"></ion-icon>
              </a>
            </li>

          </ul>

        </div>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          Copyright 2025 All Rights Reserved by <a href="https://www.eduinx.com/" class="copyright-link">eduinx</a>
        </p>

      </div>
    </div>

  </footer>


  <!-- 
    - #BACK TO TOP
  -->

  <a href="#top" class="back-top-btn" aria-label="back top top" data-back-top-btn>
    <ion-icon name="chevron-up" aria-hidden="true"></ion-icon>
  </a>

  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>
  <script src="./assets/js/elevateX.js" defer></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>