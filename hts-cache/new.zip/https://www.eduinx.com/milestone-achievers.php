<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="canonical" href="https://www.eduinx.com/milestone-achievers" />


  <!-- 
    - primary meta tag
  -->
  <title>Our Milestone Achievers | Success Stories in Data Science</title>
  <meta name="title" content="Our Milestone Achievers | Success Stories in Data Science">
  <meta name="description" content="Celebrate the success of EduInX's data science milestone achievers! Explore inspiring stories of learners who excelled and secured their dream careers.">

  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-62F9G5SR2M"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-62F9G5SR2M');
</script>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />


  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.png" type="image/svg+xml">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">
  <link rel="stylesheet" href="./assets/css/style1.css">
  
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">


  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;500;600;700;800&family=Poppins:wght@400;500&display=swap"
    rel="stylesheet">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-bg.svg">
  <link rel="preload" as="image" href="./assets/images/hero-banner-1.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-banner-2.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-shape-1.svg">
  <link rel="preload" as="image" href="./assets/images/hero-shape-2.png">

  <style type="text/css">
  .achievers{
    font-family:var(--ff-league_spartan);
    background-color: #f4f4f4;
    margin: 0;
  }
  .card-container {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 50px;
    padding: 100px 0;
    justify-content: center;
}

.card-achievers {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
    margin: 0 auto;
    max-width: 300px;
    width: 300px;
}

.card-achievers img.profile-pic {
    border-radius: 50%;
    width: 110px;
    height: 110px;
    object-fit: cover;
    align-items: center;
    margin-bottom: 10px;
    margin-left: 60px;
}

.card-achievers h2 {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-family:var(--ff-league_spartan);
    color: var(--eerie-black-1);
}

.card-achievers h2 i {
    color: #0077b5;
}

.card-achievers p {
    color: #666;
    font-size: 16px;
    margin: 5px 0;
}
.card-achievers a {
    text-decoration: none;
    color: #0077b5;
    transition: color 0.3s ease;
}

.card-achievers a:hover {
    color: #005582;
}
@media (max-width: 768px) {
    .card-achievers {
        width: 100%;
    }
}
@media(max-width: 1024px){
    .card-container {
        grid-template-columns: repeat(2, 1fr);
    }
}
@media(max-width: 640px){
    .card-container {
        grid-template-columns: repeat(1, 1fr);
    }
}
  </style>

</head>

<body id="top">
 <!-- ============== HEADER ================ -->

  
  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="index" class="logo">
        <img src="./assets/images/logo/new_logo.png" width="162" height="auto" alt="eduinx logo">
      </a>

      <nav class="navbar" data-navbar>

        <div class="wrapper">
          <a href="index" class="logo">
            <img src="./assets/images/logo/new_logo.png" width="162" height="50" alt="eduinx logo">
          </a>

          <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
            <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
          </button>
        </div>

        <ul class="navbar-list">

          <li class="navbar-item">
            <a href="./index" class="navbar-link" data-nav-link>Home</a>
          </li>

          <li class="navbar-item">
            <a href="./about-us" class="navbar-link" data-nav-link>About</a>
          </li>

          <li class="navbar-item">
            <a href="./job-guaranteed-courses" class="navbar-link" data-nav-link>Courses</a>
          </li>

          <li class="navbar-item">
            <a href="./milestone-achievers" class="navbar-link" data-nav-link>Our Milestone</a>
          </li>

          <li class="navbar-item">
            <a href="https://eduinx.in/" class="navbar-link" data-nav-link>Blogs</a>
          </li> 

          <li>
            <a href="./webinar" class="navbar-link" data-nav-link>Webinar</a>
          </li>
          
         <li>
            <a href="../elevateX" class="navbar-link" data-nav-link>ElevateX</a>
          </li>


          <li class="navbar-item">
            <a href="./contact-us" class="navbar-link" data-nav-link>Contact</a>
          </li>

          

        </ul>

      </nav>

      <div class="header-actions">
         <!-- <a href="https://wa.me/917411464640" target="_blank" class="btn has-before" style="background-color:blue;">Free Counseling</a> -->

        <a href="contact-us" class="btn has-before">
          <span class="span">Apply Now</span>

          <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
        </a>

        <button class="header-action-btn" aria-label="open menu" data-nav-toggler>
          <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
        </button>

      </div>

      <div class="overlay" data-nav-toggler data-overlay></div>

    </div>
  </header>

<!-- BODY -- ---------------------- -->

 

<section class="achievers">
    <p class="section-subtitle container" style="text-align: left; padding-top: 120px; margin-bottom:-50px;">Our Milestone Achievers > Latest Achievers</p>
  <div class="card-container">
     <!-- ACHIEVERS -->
     <div class="card-achievers">
            <img src="./assets/images/achievers/mausam.jpg" alt="Ritesh Kumar " class="profile-pic">
            <h2>Mausam Arora</h2>
            <p>Service Delivery and Ansible Automation Manager</p>
            <h3 style="color: darkred;">IBM India Pvt Ltd</h3>
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>Internship-Deep Learning & Image Processing Specialist – Land Vectorization</p>
            <h3 style="color: #b70b45;">Dr Earth AI Technologies Pvt Ltd</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>1 Lakh-Stipend</strong></h1>
        </div>
        <!-- ====================== -->
        <div class="card-achievers">
            <img src="./assets/images/achievers/amarjit.jpg" alt="Amarjit Giri" class="profile-pic">
            <h2>Amarjit Giri</h2>
            <p>Fresher</p>
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>Software Engineer Trainee</p>
            <h3 style="color: #b70b45;">iRecMan Software Solution LLP</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>8 LPA</strong></h1>
            <!-- <a href="#">Read Testimonial</a> -->
        </div>
        <!-- ====================== -->
      
      <div class="card-achievers">
            <img src="./assets/images/achievers/ritesh-kumar.jpg" alt="Ritesh Kumar " class="profile-pic">
            <h2>Ritesh Kumar</h2>
            <p>Sr Operations Manager - Customer Success</p>
            <h3 style="color: darkred;">Bluevine</h3>
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>Sr Operations Manager - Tech Team</p>
            <h3 style="color: #b70b45;">Bhanzu</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>32 LPA</strong></h1>
        </div>
        <!-- ====================== -->
      <div class="card-achievers">
            <img src="./assets/images/achievers/Soubhagya_Suman_Mohanty.jpeg" alt="Soubhagya Suman Mohanty " class="profile-pic">
            <h2>Soubhagya Suman Mohanty</h2>
            <p>Fresher</p>
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>L1 Engineer - Software Testing</p>
            <h3 style="color: #b70b45;">ApMoSys Technologies PVT LTD</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>3 LPA</strong></h1>
            <!-- <a href="#">Read Testimonial</a> -->
        </div>
        <!-- ====================== -->
      <div class="card-achievers">
            <img src="./assets/images/achievers/Dipesh_Sharma.jpeg" alt="Dipesh Sharma " class="profile-pic">
            <h2>Dipesh Sharma</h2>
            <p>Assistant Manager</p>
            <h3 style="color: darkred;">Infosys</h3>
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>Technical Support Manager</p>
            <h3 style="color: #b70b45;">Helix</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>13 LPA</strong></h1>
            <!-- <a href="#">Read Testimonial</a> -->
        </div>
        <!-- ====================== -->
      <div class="card-achievers">
            <img src="./assets/images/achievers/Prajwal.jpeg" alt="Prajwal T N" class="profile-pic">
            <h2>Prajwal T N</h2>
            <p>AM - Finance & Accounts</p>
            <h3 style="color: darkred;">PTWI INDIA PVT LTD</h3>
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>IND Consultant II</p>
            <h3 style="color: #b70b45;">AON</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>12 LPA</strong></h1>
            <!-- <a href="#">Read Testimonial</a> -->
        </div>
      
        <div class="card-achievers">
            <img src="assets/images/achievers/rohan_gs.jpg" alt="John Doe" class="profile-pic">
            <h2>Rohan G S</h2>
            <p>Fresher</p>
            <!--<h3 style="color: darkred;">IBM</h3> -->
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>Network Engineer</p>
            <h3 style="color: #b70b45;">RAS Infotech Limited</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>4.5 LPA</strong></h1>
            <!-- <a href="#">Read Testimonial</a> -->
        </div>

        <div class="card-achievers">
            <img src="assets/images/achievers/Devi_Durga_Prasad_Rath.jpg" alt="JDevi_Durga_Prasad_Rath" class="profile-pic">
            <h2>Devi Durga Prasad Rath</h2>
            <p>Graduate Engineer Trainee</p>
            <h3 style="color: #b70b45;">Lifeline Systech Solution </h3> 
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>Network Engineer</p>
            <h3 style="color: #b70b45;">Datacipher Solutions</h3>
            <!--<h1 style="color: seagreen; font-size: 25px;"><strong>4.5 LPA</strong></h1> -->
            <!-- <a href="#">Read Testimonial</a> -->
        </div>

        <div class="card-achievers">
            <img src="assets/images/achievers/Sourav_Pati.jpg" alt="Sourav_Pati" class="profile-pic">
            <h2>Sourav Pati</h2>
            <p>Network Engineer</p>
            <h3 style="color: #b70b45;">IBM</h3>
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>Network Engineer</p>
            <h3 style="color: #b70b45;">Inspira Enterprise</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>6.4 LPA</strong></h1>
            <!-- <a href="#">Read Testimonial</a> -->
        </div>

        <div class="card-achievers">
            <img src="assets/images/achievers/Srajal_Singh_Chauhan.jpg" alt="Srajal Singh Chauhan" class="profile-pic">
            <h2>Srajal Singh Chauhan</h2>
            <p>Fresher</p>
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>Software Development Associate</p>
            <h3 style="color: #b70b45;">GreensTurn Tech Ltd</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>3 LPA</strong></h1>
            <!-- <a href="">Read Testimonial</a> -->
        </div>
        <!-- ========================= -->
        <div class="card-achievers">
          <img src="assets/images/achievers/Deepak_Reddy.jpg" alt="Deepak Reddy" class="profile-pic">
          <h2>Deepak Reddy</h2>
          <p>Data Engineer</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Scientist</p>
          <h3 style="color: #b70b45;">Merxius</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>16 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->

        <div class="card-achievers">
            <img src="assets/images/achievers/Pritam_Sarkar.jpg" alt="Pritam Sarkar" class="profile-pic">
            <h2>Pritam Sarkar</h2>
            <p>Senior IT Executive</p>
            <h3 style="color: #b70b45;">PVRINOX</h3>
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>IT Senior Executive</p>
            <h3 style="color: #b70b45;">BLR Lounge</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>4 LPA</strong></h1>
            <!-- <a href="">Read Testimonial</a> -->
        </div>
        <div class="card-achievers">
            <img src="assets/images/achievers/Rahul_Prabhakar1.jpg" alt="Rahul Prabhakar" class="profile-pic">
            <h2>Rahul Prabhakar</h2>
            <p>Fresher</p>
            <!--<h3 style="color: darkred;">PVRINOX</h3> -->
            <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
            <p>Project Engineer</p>
            <h3 style="color: #b70b45;">Crio.Do</h3>
            <h1 style="color: #68bd46; font-size: 25px;"><strong>5 LPA</strong></h1>
            <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
        <div class="card-achievers">
          <img src="assets/images/achievers/Aditi_Sharma.jpg" alt="Aditi Sharma" class="profile-pic">
          <h2>Aditi Sharma</h2>
          <p>Fresher</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Network Admin</p>
          <h3 style="color: #b70b45;">EnterPi pvt Ltd</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>7 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Rohan_Gupta.jpg" alt="Rohan Gupta" class="profile-pic">
          <h2>Rohan Gupta</h2>
          <p>Project Engineer</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">Spotverge</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>9 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Sneha_Patil.jpg" alt="Sneha Patil" class="profile-pic">
          <h2>Sneha Patil</h2>
          <p>Software Developer</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Engineer</p>
          <h3 style="color: #b70b45;">NowFloats Technologies</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>11 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Pooja_Agarwal.jpg" alt="Pooja Agarwal" class="profile-pic">
          <h2>Pooja Agarwal</h2>
          <p>Network Admin</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">Datacipher Solutions</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>6.5 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Priya_Singh.jfif" alt="Priya Singh" class="profile-pic">
          <h2>Priya Singh</h2>
          <p>Technical Support Engineer</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Engineer</p>
          <h3 style="color: #b70b45;">Merxius</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>13 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Neha_Kapoor.jpg" alt="Neha Kapoor" class="profile-pic">
          <h2>Neha Kapoor</h2>
          <p>Fresher</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Security Analyst</p>
          <h3 style="color: #b70b45;">Merxius</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>7 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Karan_Mehta.jpg" alt="Karan Mehta" class="profile-pic">
          <h2>Karan Mehta</h2>
          <p>System Admin</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Security Analyst</p>
          <h3 style="color: #b70b45;">Rational Technologies</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>7 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Rajat_Joshi.jpg" alt="Rajat Joshi" class="profile-pic">
          <h2>Rajat Joshi</h2>
          <p>Fresher</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">RAS Infotech Limited</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>7.5 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Ankit_Verma.jpg" alt="Ankit Verma" class="profile-pic">
          <h2>Ankit Verma</h2>
          <p>Fresher</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Network Engineer</p>
          <h3 style="color: #b70b45;">BWJ Tech Solutions</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>9 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Manish_Pandey.jpg" alt="Manish Pandey" class="profile-pic">
          <h2>Manish Pandey</h2>
          <p>Network Analyst</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Engineer</p>
          <h3 style="color: #b70b45;">Inspira Enterprise</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>11 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Sandeep_Patil.jpg" alt="Sandeep Patil" class="profile-pic">
          <h2>Sandeep Patil</h2>
          <p>Sr. Data Analyst</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Scientist</p>
          <h3 style="color: #b70b45;">ODMS PVT LTD</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>15 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Ritu_Mahajan.jpg" alt="Ritu Mahajan" class="profile-pic">
          <h2>Ritu Mahajan</h2>
          <p>Technical Support Engineer</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Engineer</p>
          <h3 style="color: #b70b45;">Fountane Makerspace</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>12 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Aarav_Sharma.jfif" alt="Aarav Sharma" class="profile-pic">
          <h2>Aarav Sharma</h2>
          <p>Customer Support Specialist</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">Darwinbox</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>21 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Vihaan_Gupta.jfif" alt="Vihaan Gupta" class="profile-pic">
          <h2>Vihaan Gupta</h2>
          <p>Administrative Assistant</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Engineer</p>
          <h3 style="color: #b70b45;">InMobi</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>11 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Ishaan_Patel.jfif" alt="Sandeep Patil" class="profile-pic">
          <h2>Ishaan Patel</h2>
          <p>Fresher</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Researcher</p>
          <h3 style="color: #b70b45;">Hasura</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>9 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Ananya_Rao.jpg" alt="Ananya Rao" class="profile-pic">
          <h2>Ananya Rao</h2>
          <p>Marketing Analyst</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">Freshworks</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>9 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Aditi_Nair.jfif" alt="Aditi Nair" class="profile-pic">
          <h2>Aditi Nair</h2>
          <p>Digital Marketing Associate</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Quantitative Analyst</p>
          <h3 style="color: #b70b45;">Postman</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>11 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Rohan_Mehta.jpg" alt="Sandeep Patil" class="profile-pic">
          <h2>Rohan Mehta</h2>
          <p>Fresher</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">BrowserStack</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>9 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Siddharth_Iyer.jpg" alt="Siddharth Iyer" class="profile-pic">
          <h2>Siddharth Iyer</h2>
          <p>Digital Marketing Analyst</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>AI Researcher</p>
          <h3 style="color: #b70b45;">Chargebee</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>11 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Nisha_Singh.jpg" alt="Nisha" class="profile-pic">
          <h2>Nisha Singh</h2>
          <p>Fresher</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>AI Researcher</p>
          <h3 style="color: #b70b45;">Wingify</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>11 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Karthik_Reddy.jfif" alt="Karthik Reddy" class="profile-pic">
          <h2>Karthik Reddy</h2>
          <p>Customer Support Engineer</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Visualization Specialist</p>
          <h3 style="color: #b70b45;">Innovaccer</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>11 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Sneha_Chatterjee.jfif" alt="Sneha Chatterjee" class="profile-pic">
          <h2>Sneha Chatterjee</h2>
          <p>Administrative Assistant</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">Wingify</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>9 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Krishna_Desai.jfif" alt="Krishna Desai" class="profile-pic">
          <h2>Krishna Desai</h2>
          <p>Fresher</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">Hasura</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>9 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Priya_Khanna.jfif" alt="Priya Khanna" class="profile-pic">
          <h2>Priya Khanna</h2>
          <p>Customer Support</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">InMobi</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>7 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Akash_Verma1.jpg" alt="Akash Verma" class="profile-pic">
          <h2>Akash Verma</h2>
          <p>Fresher</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">InMobi</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>6.5 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Rhea_Malhotra.jfif" alt="Rhea Malhotra" class="profile-pic">
          <h2>Rhea Malhotra</h2>
          <p>Network Engineer</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Analyst</p>
          <h3 style="color: #b70b45;">Druva</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>9 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->
<div class="card-achievers">
          <img src="assets/images/achievers/Manav_Bhatia1.jpg" alt="Manav Bhatia" class="profile-pic">
          <h2>Manav Bhatia</h2>
          <p>Marketing Associate</p>
          <span style='font-size:40px; color: #68bd46; margin-bottom: -20px; margin-top: -20px;'>&#8659;</span>
          <p>Data Visualization Specialist</p>
          <h3 style="color: #b70b45;">RAS Infotech</h3>
          <h1 style="color: #68bd46; font-size: 25px;"><strong>8 LPA</strong></h1>
          <!-- <a href="">Read Testimonial</a> -->
        </div>
<!-- =========================== -->

    </div>

</section>

<!-- -------BODY END -------------------------- -->

 <!-- ============== FOOTER ================ -->

    <!-- 
    - #FOOTER
  -->

  <footer class="footer" style="background-image: url('./assets/images/footer-bg.png')">

    <div class="footer-top section">
      <div class="container grid-list">

        <div class="footer-brand">

          <a href="#" class="logo">
            <img src="./assets/images/logo/new_logo_white.png" width="162" height="50" alt="eduinx logo">
          </a>

          <p class="footer-brand-text">
            At Eduinx, we offer comprehensive online courses with expert instructors and cutting-edge curriculum, Eduinx is the perfect choice for those serious about success in the tech industry.
          </p>

         <!-- <div class="wrapper">
            <span class="span">Address:</span>

            <address class="address"> B-Block, BHIVE Workspace - No.112, AKR Tech Park, "A" and, 7th Mile Hosur Rd, Krishna Reddy Industrial Area, Bengaluru, Karnataka- s560068</address>
          </div> -->

          <div class="wrapper">
            <span class="span">Call:</span>

            <a href="tel:+917411464640" class="footer-link">+91 7411 464 640</a>
          </div>

          <div class="wrapper">
            <span class="span">Email:</span>

            <a href="mailto:support@eduinx.com" class="footer-link">support@eduinx.com</a>
          </div>

        </div>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Comapny</p>
          </li>

          <li>
            <a href="about-us" class="footer-link">About</a>
          </li>

          <li>
            <a href="job-guaranteed-courses" class="footer-link">Courses</a>
          </li>


          <li>
            <a href="policy/Privacy-Policy" class="footer-link">Privacy Policy</a>
          </li>

          <li>
            <a href="policy/terms-and-conditions" class="footer-link">Terms & Conditions</a>
          </li>

          <li>
            <a href="policy/refund-cancellation-policy" class="footer-link">Refund/Cancellation policy</a>
          </li>

          <!--<li>-->
          <!--  <a href="policy/cancellation-policy" class="footer-link">Cancellation Policy</a>-->
          <!--</li>-->

        </ul>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Links</p>
          </li>

          <li>
            <a href="contact-us" class="footer-link">Contact Us</a>
          </li>


          <li>
            <a href="instructors" class="footer-link">Instructor</a>
          </li> 

          <li>
            <a href="our-team" class="footer-link">Our Team</a>
          </li>

          <li>
            <a href="https://eduinx.in/" class="footer-link">Blogs</a>
          </li>

          <!--<li>-->
          <!--  <a href="news-updates" class="footer-link">News</a>-->
          <!--</li>-->
          
          <!--<li>
            <a href="current-openings" class="footer-link">Current Openings</a>
          </li> -->

          <li>
            <a href="faqs" class="footer-link">FAQs</a>
          </li>
          
          <li>
              <a
                href="https://www.google.com/search?sca_esv=0e58669465c64ea2&rlz=1C1CHBF_enIN1024IN1024&sxsrf=AE3TifPDQXz4KGp_OPnFaNKkzY5IjuTYkA:1750921551557&si=AMgyJEtREmoPL4P1I5IDCfuA8gybfVI2d5Uj7QMwYCZHKDZ-E1oJ7PBp83PEWzfEE9P0MDjL0cfOCHY1-lOgc1vdWqwnRkzMJyy_fGEJbvyYLZ_huGqqZ7dewNNaquMeY9EO6NJbz-X9&q=Eduinx+Pvt+Ltd+Reviews&sa=X&ved=2ahUKEwiQwfCIw46OAxUPzTgGHQGjKBYQ0bkNegQINBAE&cshid=1750921567441879&biw=1536&bih=695&dpr=1.25#lrd=0x890b8701b2132843:0x20a4928ed3930407,3,,,,"
                class="footer-link"
                >Review Us</a
              >
            </li>

        </ul>

        <div class="footer-list">

          <p class="footer-list-title">Contacts</p>

          <p class="footer-list-text">
            Enter your email address to register to our newsletter subscription
          </p>

          <form action="" class="newsletter-form">
            <input type="email" name="email_address" placeholder="Your email" required class="input-field">

            <button type="submit" class="btn has-before">
              <span class="span">Subscribe</span>

              <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
            </button>
          </form>

          <ul class="social-list">

            <li>
              <a href="https://www.facebook.com/profile.php?id=61554376480864&mibextid=nwBsNb" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.linkedin.com/company/eduinx-com/" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-linkedin"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.instagram.com/eduinx.s?igsh=aWFlYmExYTdxdDA5&utm_source=qr" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-instagram"></ion-icon>
              </a>
            </li>

            <!--<li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li> -->

            <li>
              <a href="https://www.youtube.com/@eduinx-LeadwithSkills" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-youtube"></ion-icon>
              </a>
            </li>

          </ul>

        </div>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          Copyright 2025 All Rights Reserved by <a href="https://www.eduinx.com/" class="copyright-link">eduinx</a>
        </p>

      </div>
    </div>

  </footer>

  <!-- 
    - #BACK TO TOP
  -->

  <a href="#top" class="back-top-btn" aria-label="back top top" data-back-top-btn>
    <ion-icon name="chevron-up" aria-hidden="true"></ion-icon>
  </a>


  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

  <!-- Achievers script -->
  <!--<script type="text/javascript">
    var btn5 = document.getElementsByClassName("btn5");
    var slide = document.getElementById("slide");

    btn5[0].onclick = function(){
      slide.style.transform = "translateX(0px)";
      for(i=0;i<4;i++){
        btn5[i].classList.remove("active");
      }
    }

    btn5[1].onclick = function(){
      slide.style.transform = "translateX(-8px)";
      for(i=0;i<4;i++){
        btn5[i].classList.remove("active");
      }
    }

    btn5[2].onclick = function(){
      slide.style.transform = "translateX(-16px)";
      for(i=0;i<4;i++){
        btn5[i].classList.remove("active");
      }
    }

    btn5[3].onclick = function(){
      slide.style.transform = "translateX(-24px)";
      for(i=0;i<4;i++){
        btn5[i].classList.remove("active");
      }
    }

  </script> 

  <script type="text/javascript">
    var btn5 = document.getElementsByClassName("btn5");
    var slide = document.getElementById("slide");

    for (let i = 0; i < btn5.length; i++) {
        btn5[i].onclick = function() {
            // Set the transform based on the clicked button index
            slide.style.transform = `translateX(-${i * 800}px)`;
            // Remove the 'active' class from all buttons
            for (let j = 0; j < btn5.length; j++) {
                btn5[j].classList.remove("active");
            }
            // Add the 'active' class to the clicked button
            this.classList.add("active");
        };
    }
</script>
-->

 <script type="text/javascript">
        document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('mouseover', () => {
        card.style.boxShadow = '0 8px 16px rgba(0, 0, 0, 0.2)';
    });

    card.addEventListener('mouseout', () => {
        card.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)';
    });
});

    </script>

</body>

</html>