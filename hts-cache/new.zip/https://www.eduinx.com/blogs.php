<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- 
    - primary meta tag
  -->
  <title>EduInX Blogs | Insights and Tips on Data Science & Career Growth</title>

  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

  <meta name="title" content="EduInX Blogs | Insights and Tips on Data Science & Career Growth">
  <meta name="description" content="Explore the EduInX blog for expert insights, practical tips, and the latest trends in data science. Boost your knowledge and advance your career today!">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />


  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.png" type="image/svg+xml">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">
  <link rel="stylesheet" href="./assets/css/style1.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=League+Spartan:wght@400;500;600;700;800&family=Poppins:wght@400;500&display=swap"
    rel="stylesheet">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-bg.svg">
  <link rel="preload" as="image" href="./assets/images/hero-banner-1.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-banner-2.jpg">
  <link rel="preload" as="image" href="./assets/images/hero-shape-1.svg">
  <link rel="preload" as="image" href="./assets/images/hero-shape-2.png">

  <style type="text/css">
    .blog-sec {
            display: flex;
            flex-wrap: wrap;
            margin: 20px;
            gap: 20px;
        }

        .blog-sec img {
            max-width: 60%;
            height: auto;
            border-radius: 10px;
            text-align: left;
            display: block;
            margin: 10 auto;

        }

        .blog-description {
            flex: 2;
            display: flex;
            flex-direction: column;
        }

        .blog-description h3 {
            margin: 5px 0;
            color: #555;
            font-size: 15px;
        }

        .author-name a h3:hover{
          color: #0077ff;
        }


        .blog-description h1 {
            margin: 10px 0;
            font-size: 18px;
            color: #333;
        }

        .blog-description h1:hover{
          color: #0077ff;
        }

        .blog-description p {
            margin: 10px 0;
            line-height: 1.6;
            color: #666;
        }

        .author-name {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            color: #888;
        }

        @media (max-width: 768px) {
            .blog-sec {
                flex-direction: column;
                align-items: flex-start;
            }
            .blog-sec img{
                max-width: 100%;
                height: auto;
            }


            .author-name {
                flex-direction: column;
                align-items: flex-start;
            }
            
        } 
/* ========== TRENDING ========== */
        .section-header {
            display: flex;
            align-items: center;
        }

        .section-header .label {
            background-color: #0077ff;
            color: #000;
            font-weight: bold;
            padding: 5px 15px;
            border-radius: 4px;
            font-size: 16px;
        }

        .section-header .line {
            flex-grow: 1;
            height: 1px;
            background-color: #ddd;
            margin-left: 10px;
        }
         @media (max-width: 768px) {
            .section-header {
                margin-bottom: 10px;
            }
        }
  /* ========= BLOG LIST =========== */
  .articles {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .articles-section {
            display: flex;
            gap: 30px;
        }

        .article-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 350px;
        }

        .article-card img {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }

        .article-content {
            padding: 15px;
        }

        .article-content a h3:hover{
          color: darkblue;
        }

        .article-content .tag {
            display: inline-block;
            background-color: #0077ff;
            color: white;
            font-size: 12px;
            font-weight: bold;
            padding: 2px 8px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .article-content h3 {
            font-size: 18px;
            margin: 10px 0;
            color: #333;
        }

        .article-content p {
            font-size: 14px;
            color: #666;
            line-height: 1.5;
        }

        .article-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }

        .article-footer .author {
            display: flex;
            align-items: center;
        }

        .article-footer img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .article-footer .date {
            font-size: 12px;
            color: #999;
        }
        @media (max-width: 768px) {
            .articles-section {
                flex-direction: column;
                align-items: center;
            }
            .article-card{
              margin-bottom: 100px;
            }
        }
/* =========== PAGINATION ================ */
.pagination-list {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
.pagination {
            display: flex;
            flex-wrap: wrap;
            list-style: none;
            padding: 0;
            margin: 0;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .pagination li {
            display: inline;
        }

        .pagination li a {
            text-decoration: none;
            padding: 10px 15px;
            display: block;
            color: #007bff;
            border-right: 1px solid #ddd;
            white-space: nowrap;
        }

        .pagination li a:hover {
            background-color: #f1f1f1;
        }

        .pagination li:first-child a {
            border-top-left-radius: 5px;
            border-bottom-left-radius: 5px;
        }

        .pagination li:last-child a {
            border-right: none;
            border-top-right-radius: 5px;
            border-bottom-right-radius: 5px;
        }

        .pagination li a.active {
            background-color: #001f3f;
            color: white;
            font-weight: bold;
        }

        .pagination li.disabled a {
            color: #ccc;
            pointer-events: none;
        }

        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            .pagination li a {
                padding: 8px 10px;
                font-size: 14px;
            }

            .pagination {
                justify-content: center;
            }
        }
  /* ============= COUNTDOWN TOP BANNER ================== */
/*.top-banner {
            background-color: #0077ff;
            color: #ffffff;
            text-align: center;
            padding: 10px 15px;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            justify-content: center;
            align-items: center;
        }

        .top-banner .message {
            font-size: 16px;
            font-weight: bold;
            margin-right: 10px;
            color: ;
        }

        .top-banner .timer {
            font-size: 16px;
            font-weight: bold;
        }

        @media (max-width: 600px) {
            .top-banner {
                font-size: 14px;
                padding: 8px 10px;
            }

            .top-banner .message,
            .top-banner .timer {
                font-size: 14px;
            }
        } */
  </style>

</head>

<body id="top">
 <!-- ============== HEADER ================ -->

  
  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="index" class="logo">
        <img src="./assets/images/logo/new_logo.png" width="162" height="auto" alt="eduinx logo">
      </a>

      <nav class="navbar" data-navbar>

        <div class="wrapper">
          <a href="index" class="logo">
            <img src="./assets/images/logo/new_logo.png" width="162" height="50" alt="eduinx logo">
          </a>

          <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
            <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
          </button>
        </div>

        <ul class="navbar-list">

          <li class="navbar-item">
            <a href="./index" class="navbar-link" data-nav-link>Home</a>
          </li>

          <li class="navbar-item">
            <a href="./about-us" class="navbar-link" data-nav-link>About</a>
          </li>

          <li class="navbar-item">
            <a href="./job-guaranteed-courses" class="navbar-link" data-nav-link>Courses</a>
          </li>

          <li class="navbar-item">
            <a href="./milestone-achievers" class="navbar-link" data-nav-link>Our Milestone</a>
          </li>

          <li class="navbar-item">
            <a href="https://eduinx.in/" class="navbar-link" data-nav-link>Blogs</a>
          </li> 

          <li>
            <a href="./webinar" class="navbar-link" data-nav-link>Webinar</a>
          </li>
          
         <li>
            <a href="../elevateX" class="navbar-link" data-nav-link>ElevateX</a>
          </li>


          <li class="navbar-item">
            <a href="./contact-us" class="navbar-link" data-nav-link>Contact</a>
          </li>

          

        </ul>

      </nav>

      <div class="header-actions">
         <!-- <a href="https://wa.me/917411464640" target="_blank" class="btn has-before" style="background-color:blue;">Free Counseling</a> -->

        <a href="contact-us" class="btn has-before">
          <span class="span">Apply Now</span>

          <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
        </a>

        <button class="header-action-btn" aria-label="open menu" data-nav-toggler>
          <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
        </button>

      </div>

      <div class="overlay" data-nav-toggler data-overlay></div>

    </div>
  </header>
 

<!-- BODY -- ---------------------- -->
      <!-- 
        - #BLOG
      -->
  <section class="section blog has-bg-image" id="blog" aria-label="blog">
    <div class="container">
      <p class="section-subtitle" style="text-align: left;">Articles > Latest Articles</p>
      <!-- <h2 class="h2 section-title">Get News With Eduinx</h2> -->

<div class="blog-sec">
  <img src="./assets/images/articles/article_21.png" alt="AI Product Management Skills">
  <div class="blog-description">
    <h3 style="background-color: #0077ff; color:white; width: 180px; text-align: center;">Generative AI </h3>
    <a href="./blog-repository/ai-product-manager-skills"><h1>6 Key Skills That Are A Must For AI Product Managers</h1></a>

  <p>As a product manager in today’s AI-driven landscape, just knowing everything about the product and basic soft skills are not enough for you to make a deep impact in the current competitive industry. It is vital to understand the nuances of AI, machine learning, deep learning, large language models, and neural networks. Most importantly, you need to understand how these core concepts influence product management and decision-making. <a href="./blog-repository/ai-product-manager-skills" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p><br>
    <div class="author-name">
      <a href="../assets/images/articles/author/Akassh_Vijay.jpg"><h3>Akassh Vijay</h3></a> 
      <h3>April 7, 2025</h3>
    </div>
  </div>
</div> <br>
<!-- ========== TRENDING ============= -->
<div class="section-header">
        <div class="label">Trending</div>
        <div class="line"></div>
    </div>
<!-- ==================== -->
<section class="articles">
  <div class="articles-section">
     <!-- ======================================= -->
     <div class="article-card">
        <img src="./assets/images/articles/article_20.png" alt="AI Product Management Guide">
            <div class="article-content">
                <span class="tag">Generative AI</span>
                <a href="./blog-repository/ai-product-management-guide"> <h3>All You Need to Know About AI Product Management</h3></a>
                <p>Did you know that <a href="https://airfocus.com/blog/surprising-product-management-stats/" target="_blank" style="display: inline; color: deepskyblue;">92%</a> of product managers (PMs) <a href="./blog-repository/ai-product-management-guide" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">April 4, 2025</span>
                </div>
            </div>
        </div>
<!-- =========================================== -->
     <div class="article-card">
        <img src="./assets/images/articles/article_19.png" alt="AI Product Managers">
            <div class="article-content">
                <span class="tag">Generative AI</span>
                <a href="./blog-repository/ai-product-manager-roles-skills-future"> <h3>AI Product Managers: Roles, Responsibilities, and Future Scope</h3></a>
                <p>Did you know that a highly skilled product manager<a href="./blog-repository/ai-product-manager-roles-skills-future" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">March 31, 2025</span>
                </div>
            </div>
        </div>
<!-- =========================================== -->
      <div class="article-card">
        <img src="./assets/images/articles/article_18.png" alt="Generative AI: A Deep Dive">
            <div class="article-content">
                <span class="tag">AGENT AI</span>
                <a href="./blog-repository/generative-ai-deep-dive"> <h3>Generative AI: A Deep Dive</h3></a>
                <p>Did you know that <a href="https://www.salesforce.com/news/stories/generative-ai-statistics/" target="_blank" style="display: inline; color: deepskyblue;">75%</a> of gen AI users are looking <a href="./blog-repository/generative-ai-deep-dive" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">March 28, 2025</span>
                </div>
            </div>
        </div>
<!-- =========================================== -->
         
    </div>
</section>
<!-- ========== ALL POST ============= -->
<div class="section-header">
        <div class="label">ALL POST</div>
        <div class="line"></div>
    </div>
<!-- ========= Section -3 =========== -->
<section class="articles">
  <div class="articles-section">        
    <!-- ====================================== -->
     <div class="article-card">
        <img src="./assets/images/articles/article_17.png" alt="AI Agents and Autonomous AI Agent">
            <div class="article-content">
                <span class="tag">AGENT AI</span>
                <a href="./blog-repository/ai-agents-and-autonomous-ai-agent"> <h3>AI Agents and Autonomous AI Agents: A Deep Dive</h3></a>
                <p>With nearly <a href="https://www.sellerscommerce.com/blog/ai-agents-statistics/" target="_blank" style="display: inline; color: deepskyblue;">79%</a> of employees stating that <a href="./blog-repository/ai-agents-and-autonomous-ai-agent" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">March 24, 2025</span>
                </div>
            </div>
        </div>
    <!-- ======================================= --> 
     <div class="article-card">
        <img src="./assets/images/articles/article_16.png" alt="Agent AI">
            <div class="article-content">
                <span class="tag">AGENT AI</span>
                <a href="./blog-repository/agent-ai-boon-or-bane"> <h3>Is Agent AI a Boon or a Bane?</h3></a>
                <p>Did you know that AI agents are predicted to handle <a href="https://www.sellerscommerce.com/blog/ai-agents-statistics/#:~:text=Here%20are%20some%20key%20statistics%20about%20AI%20agents%20in%20customer,agents%20as%20a%20competitive%20advantage." target="_blank" style="display: inline; color: deepskyblue;">80%</a> of all customer interactions by 2030?<a href="./blog-repository/agent-ai-boon-or-bane" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">March 10, 2025</span>
                </div>
            </div>
        </div>
    <!-- ======================================= -->
    <div class="article-card">
        <img src="./assets/images/articles/article_15.png" alt="Agent AI">
            <div class="article-content">
                <span class="tag">AGENT AI</span>
                <a href="./blog-repository/agent-ai-what-is-it-and-how-does-it-work"> <h3>Agent AI: What Is It And How Does It Work?</h3></a>
                <p>With an increase in expectations and tangible advancements in the field of AI, generative AI,<a href="./blog-repository/agent-ai-what-is-it-and-how-does-it-work" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">March 03, 2025</span>
                </div>
            </div>
        </div>
<!-- ====================================== -->
    
    </div>
</section>
<!-- ========== Section -2 =============== -->
<section class="articles">
  <div class="articles-section"> 
      <!-- ======================================= -->
       <div class="article-card">
        <img src="./assets/images/articles/article_14.png" alt="Ethical Privacy Considerations">
            <div class="article-content">
                <span class="tag">BIG DATA </span>
                <a href="./blog-repository/ethical-privacy-considerations-generative-ai-data-science"> <h3>Ethical Privacy Considerations While Using Generative AI In Data Science</h3></a>
                <p>With new technologies and breakthroughs in generative AI,<a href="./blog-repository/ethical-privacy-considerations-generative-ai-data-science" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">Feb 28, 2025</span>
                </div>
            </div>
        </div>

<!-- ====================================== -->
       <div class="article-card">
        <img src="./assets/images/articles/article_13.png" alt="Capstone Project">
            <div class="article-content">
                <span class="tag">BIG DATA </span>
                <a href="./blog-repository/what-is-a-capstone-project-importance-benefits"> <h3>What is a Capstone Project? Why is it Essential?</h3></a>
                <p>A typical Indian education system comprises teachers teaching concepts and performing practical experiments.<a href="./blog-repository/what-is-a-capstone-project-importance-benefits" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">Feb 25, 2025</span>
                </div>
            </div>
        </div>
<!-- ============================================== -->
      <div class="article-card">
        <img src="./assets/images/articles/article_12.png" alt="Understanding the Hadoop Ecosystem in Big Data">
            <div class="article-content">
                <span class="tag">BIG DATA </span>
                <a href="./blog-repository/understanding-hadoop-ecosystem-big-data"> <h3>Understanding the Hadoop Ecosystem In Big Data</h3></a>
                <p>As one of the key tools used by organizations to store and analyze data,<a href="./blog-repository/understanding-hadoop-ecosystem-big-data" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">Feb 22, 2025</span>
                </div>
            </div>
        </div>
<!-- ====================================== --> 
          
   </div>
</section> 
<!-- ======== Section -1 ================= -->
<section class="articles">
  <div class="articles-section"> 
     <!-- ======================================= -->
     <div class="article-card">
        <img src="./assets/images/articles/article_11.png" alt="Popular Big Data Technology">
            <div class="article-content">
                <span class="tag">BIG DATA </span>
                <a href="./blog-repository/popular-big-data-technologies-in-data-science"> <h3>8 Popular Big Data Technology Used In Data Science</h3></a>
                <p>What is Big Data? As a data science engineer, whenever you deal with large unstructured data <a href="./blog-repository/popular-big-data-technologies-in-data-science" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">Feb 20, 2025</span>
                </div>
            </div>
        </div>
  
    <!-- ======================================= -->
     <div class="article-card">
        <img src="./assets/images/articles/article_10.png" alt="Lifecycle Of AI In Data Science">
            <div class="article-content">
                <span class="tag">DATA SCIENCE</span>
                <a href="./blog-repository/lifecycle-of-data-science-real-time-applications"> <h3>Lifecycle Of Data Science And Its Real-time Applications</h3></a>
                <p>As a professional data science engineer or a fresh graduate aspiring to build your career, <a href="./blog-repository/lifecycle-of-data-science-real-time-applications" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 

                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">Feb 14, 2025</span>
                </div>
            </div>
        </div>
        <!-- ========================================== -->

     <div class="article-card">
        <img src="./assets/images/articles/article_9.png" alt="Lifecycle Of AI In Data Science">
            <div class="article-content">
                <span class="tag">DATA SCIENCE</span>
                <a href="./blog-repository/lifecycle-ai-data-science"> <h3>Lifecycle Of AI In Data Science</h3></a>
                <p>Artificial intelligence has revolutionized several organizations across various industries. <a href="./blog-repository/lifecycle-ai-data-science" style="color:skyblue;">Learn More <i class="fa fa-arrow-right"></i></a></p> 
                <div class="article-footer">
                    <div class="author">
                        <img src="./assets/images/articles/author/Akassh_Vijay.jpg" alt="Author Sayana Lam">
                        <span>Akassh Vijay</span>
                        <a href="https://www.linkedin.com/in/akassh-vijay-b4548483/" target="_blank" style="display: inline-block; margin-left: 15px; margin-top: 10px;">
                          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="#0077b5" viewBox="0 0 24 24">
                            <path d="M22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.73V1.73C24 .77 23.21 0 22.23 0zM7.12 20.45H3.56V9h3.56v11.45zm-1.78-12.9a2.07 2.07 0 110-4.14 2.07 2.07 0 010 4.14zM20.45 20.45h-3.56v-5.67c0-1.35-.03-3.09-1.88-3.09-1.88 0-2.17 1.47-2.17 2.99v5.77H9.28V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29z"/>
                          </svg>
                        </a>
                    </div>
                    <span class="date">Feb 12, 2025</span>
                </div>
            </div>
        </div>
    <!-- ======================================= -->
    </div>
</section>

<center><a href="all-blogs"><button style="padding: 15px 25px; "> View All</button></a></center>
</div>

    </div>
  </section>

  </article>
</main>



  <!-- Blogs -->

  
  
<!-- -------BODY END -------------------------- -->

 <!-- ============== FOOTER ================ -->

    <!-- 
    - #FOOTER
  -->

  <footer class="footer" style="background-image: url('./assets/images/footer-bg.png')">

    <div class="footer-top section">
      <div class="container grid-list">

        <div class="footer-brand">

          <a href="#" class="logo">
            <img src="./assets/images/logo/new_logo_white.png" width="162" height="50" alt="eduinx logo">
          </a>

          <p class="footer-brand-text">
            At Eduinx, we offer comprehensive online courses with expert instructors and cutting-edge curriculum, Eduinx is the perfect choice for those serious about success in the tech industry.
          </p>

         <!-- <div class="wrapper">
            <span class="span">Address:</span>

            <address class="address"> B-Block, BHIVE Workspace - No.112, AKR Tech Park, "A" and, 7th Mile Hosur Rd, Krishna Reddy Industrial Area, Bengaluru, Karnataka- s560068</address>
          </div> -->

          <div class="wrapper">
            <span class="span">Call:</span>

            <a href="tel:+917411464640" class="footer-link">+91 7411 464 640</a>
          </div>

          <div class="wrapper">
            <span class="span">Email:</span>

            <a href="mailto:support@eduinx.com" class="footer-link">support@eduinx.com</a>
          </div>

        </div>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Comapny</p>
          </li>

          <li>
            <a href="about-us" class="footer-link">About</a>
          </li>

          <li>
            <a href="job-guaranteed-courses" class="footer-link">Courses</a>
          </li>


          <li>
            <a href="policy/Privacy-Policy" class="footer-link">Privacy Policy</a>
          </li>

          <li>
            <a href="policy/terms-and-conditions" class="footer-link">Terms & Conditions</a>
          </li>

          <li>
            <a href="policy/refund-cancellation-policy" class="footer-link">Refund/Cancellation policy</a>
          </li>

          <!--<li>-->
          <!--  <a href="policy/cancellation-policy" class="footer-link">Cancellation Policy</a>-->
          <!--</li>-->

        </ul>

        <ul class="footer-list">

          <li>
            <p class="footer-list-title">Links</p>
          </li>

          <li>
            <a href="contact-us" class="footer-link">Contact Us</a>
          </li>


          <li>
            <a href="instructors" class="footer-link">Instructor</a>
          </li> 

          <li>
            <a href="our-team" class="footer-link">Our Team</a>
          </li>

          <li>
            <a href="https://eduinx.in/" class="footer-link">Blogs</a>
          </li>

          <!--<li>-->
          <!--  <a href="news-updates" class="footer-link">News</a>-->
          <!--</li>-->
          
          <!--<li>
            <a href="current-openings" class="footer-link">Current Openings</a>
          </li> -->

          <li>
            <a href="faqs" class="footer-link">FAQs</a>
          </li>
          
          <li>
              <a
                href="https://www.google.com/search?sca_esv=0e58669465c64ea2&rlz=1C1CHBF_enIN1024IN1024&sxsrf=AE3TifPDQXz4KGp_OPnFaNKkzY5IjuTYkA:1750921551557&si=AMgyJEtREmoPL4P1I5IDCfuA8gybfVI2d5Uj7QMwYCZHKDZ-E1oJ7PBp83PEWzfEE9P0MDjL0cfOCHY1-lOgc1vdWqwnRkzMJyy_fGEJbvyYLZ_huGqqZ7dewNNaquMeY9EO6NJbz-X9&q=Eduinx+Pvt+Ltd+Reviews&sa=X&ved=2ahUKEwiQwfCIw46OAxUPzTgGHQGjKBYQ0bkNegQINBAE&cshid=1750921567441879&biw=1536&bih=695&dpr=1.25#lrd=0x890b8701b2132843:0x20a4928ed3930407,3,,,,"
                class="footer-link"
                >Review Us</a
              >
            </li>

        </ul>

        <div class="footer-list">

          <p class="footer-list-title">Contacts</p>

          <p class="footer-list-text">
            Enter your email address to register to our newsletter subscription
          </p>

          <form action="" class="newsletter-form">
            <input type="email" name="email_address" placeholder="Your email" required class="input-field">

            <button type="submit" class="btn has-before">
              <span class="span">Subscribe</span>

              <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
            </button>
          </form>

          <ul class="social-list">

            <li>
              <a href="https://www.facebook.com/profile.php?id=61554376480864&mibextid=nwBsNb" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.linkedin.com/company/eduinx-com/" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-linkedin"></ion-icon>
              </a>
            </li>

            <li>
              <a href="https://www.instagram.com/eduinx.s?igsh=aWFlYmExYTdxdDA5&utm_source=qr" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-instagram"></ion-icon>
              </a>
            </li>

            <!--<li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li> -->

            <li>
              <a href="https://www.youtube.com/@eduinx-LeadwithSkills" class="social-link" target="_blank" rel="noopener noreferrer">
                <ion-icon name="logo-youtube"></ion-icon>
              </a>
            </li>

          </ul>

        </div>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          Copyright 2025 All Rights Reserved by <a href="https://www.eduinx.com/" class="copyright-link">eduinx</a>
        </p>

      </div>
    </div>

  </footer>

  <!-- 
    - #BACK TO TOP
  -->

  <a href="#top" class="back-top-btn" aria-label="back top top" data-back-top-btn>
    <ion-icon name="chevron-up" aria-hidden="true"></ion-icon>
  </a>


  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

  <!-- ==== PAGINATION ============= -->
  <!--<script>
document.addEventListener("DOMContentLoaded", function () {
    const pagination = document.querySelector('.pagination');
    if (!pagination) return;

    const pages = pagination.querySelectorAll('li a');
    const totalPages = 10;
    let currentPage = new URLSearchParams(window.location.search).get('page') || 1;
    currentPage = parseInt(currentPage);

    function updatePagination() {
        pages.forEach((page) => {
            const pageNumber = Number(page.textContent);
            page.classList.remove('active');
            page.parentElement.classList.remove('disabled', 'hidden');

            if (!isNaN(pageNumber)) {
                page.href = `?page=${pageNumber}`;
                if (pageNumber === currentPage) {
                    page.classList.add('active');
                }

                // Hide extra pages dynamically
                if (pageNumber > currentPage + 2 || pageNumber < currentPage - 2) {
                    page.parentElement.classList.add('hidden');
                }
            }
        });

        // Update Previous/Next button links and states
        const prev = document.querySelector('.prev');
        const next = document.querySelector('.next');

        prev.href = `?page=${Math.max(1, currentPage - 1)}`;
        next.href = `?page=${Math.min(totalPages, currentPage + 1)}`;

        if (currentPage === 1) prev.parentElement.classList.add('disabled');
        if (currentPage === totalPages) next.parentElement.classList.add('disabled');
    }

    updatePagination();
});
</script> -->
<!-- ========= COUNTDOWN ================== -->

<!--<script>
    function startCountdown(durationInSeconds) {
        const countdownElement = document.getElementById('countdown');
        let remainingTime = durationInSeconds;

        function updateTimer() {
            const hours = Math.floor((remainingTime % (60 * 60 * 24)) / (60 * 60));
            const minutes = Math.floor((remainingTime % (60 * 60)) / 60);
            const seconds = Math.floor(remainingTime % 60);

            countdownElement.textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            if (remainingTime > 0) {
                remainingTime--;
            } else {
                clearInterval(timerInterval);
                countdownElement.textContent = '00:00:00';
            }
        }

        updateTimer(); // Initialize timer immediately
        const timerInterval = setInterval(updateTimer, 1000);
    }

    // Set countdown duration (e.g., 2 hours = 7200 seconds)
    const durationInSeconds = 2 * 60 * 60; 
    startCountdown(durationInSeconds);
</script> -->

</body>

</html>